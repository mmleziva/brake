#include "variousfcs.h"

controlbits controls;
uint8_t swec;
bint swfil;

inline void inivarifcs(void)
{
 swfil.i=0xffff;   
 controls.SWITCH= true;
 controls.SWLAST= true;
}

inline void buttonfilt(void)
{
    swec ++;
   swec &= 0x07;
   switch(swec)
   {
       case 0:
           SWEN= true;  //turn output to input
           break;
       case 1:              
           swfil.L<<=1; //shift of filtering byte
           swfil.b0= SW;   //setting of its first bit according to button state
           if(swfil.L == 0xff)
                controls.SWITCH= true;  //filtering state of button
           else if(swfil.L == 0x00)
                controls.SWITCH= false;
           if(!controls.SWITCH && controls.SWLAST)
                controls.SWREAL= true;      //set rising edge of button
           else if(controls.SWITCH && !controls.SWLAST)
               controls.SWUNRE= true;      //set falling edge of button
                controls.SWLAST= controls.SWITCH;
           break;
       case 2:
           SWEN= false;  //change input to output
           break;
       default:
           break;     
   }
}

inline void pwmvolt(int permilleratio)
{
     uint32_t lotr;
     if(permilleratio > 1000)permilleratio = 1000;
     else if(permilleratio < -1000)permilleratio = -1000;
     lotr= ((uint32_t)(permilleratio + 0x400)) * PTPER;//t
     MDC= lotr >> 11; 
}

void Filt(adcfilter *pADCfilter)//adc  filter
{
  unil  filu;
  if(!pADCfilter->BEGIN) // start filtering 
  {
      pADCfilter->BEGIN=true;
      pADCfilter->filter = pADCfilter->adc;
  }
  else      //continuous filtering
  {
       filu.i= pADCfilter->filter;
       filu.j= 0;
       filu.il += (pADCfilter->kfil) * (uint32_t)(pADCfilter->adc - pADCfilter->filter);
      pADCfilter->filter= filu.i;
  }
}